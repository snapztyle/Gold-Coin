# 存证合约 Plus 版本

**业务需求：** 

在部分场景中，需对合约 Key 进行指定。

因此，对原有 Evidence 存证合约进行了增强。

**新功能点描述：** 

增强功能点包括：

- 增加 newEvidenceEventWithKey 事件
- 增加 newEvidenceByKey 方法
- 增加 getEvidenceByKey 方法
